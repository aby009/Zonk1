package com.project.pkalilebar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText edtPanjang;
    private EditText edtLebar;
    private EditText edtTinggi;
    private Button btnHitung;
    private TextView txtHasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtPanjang = findViewById(R.id.edtPanjang);
        edtLebar = findViewById(R.id.edtLebar);
        edtTinggi = findViewById(R.id.edtTinggi);
        btnHitung = findViewById(R.id.btnHitung);
        txtHasil =findViewById(R.id.txtHasil);

        btnHitung.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
    if(v.getId()==R.id.btnHitung){
        Log.d("Capture Log", "Button hitung di click");

        String inputPanjang = edtPanjang.getText().toString().trim();
        String inputLebar = edtLebar.getText().toString().trim();
        String inputTinggi = edtTinggi.getText().toString().trim();

        Double hasil = Double.valueOf(inputPanjang) * Double.valueOf(inputLebar) * Double.valueOf(inputTinggi);

        txtHasil.setText(String.valueOf(hasil));
    }
    }

}